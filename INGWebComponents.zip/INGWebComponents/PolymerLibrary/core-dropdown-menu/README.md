core-dropdown-menu
==================

owner: @morethanreal

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-dropdown-menu) for more information.
