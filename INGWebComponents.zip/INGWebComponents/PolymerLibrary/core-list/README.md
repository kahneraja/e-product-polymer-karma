core-list
============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-list) for more information.
