core-doc-viewer
================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-doc-viewer) for more information.


**Note** If you update elements in this repo, you'll need to rebuild `build.sh` in [core-component-page-dev](https://github.com/Polymer/core-component-page-dev) so they're used in the compiled version (core-component-page).
