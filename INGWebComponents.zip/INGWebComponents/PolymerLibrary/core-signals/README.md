core-signals
============

See the [component  page](http://www.polymer-project.org/docs/elements/core-elements.html#core-signals) for more information.
