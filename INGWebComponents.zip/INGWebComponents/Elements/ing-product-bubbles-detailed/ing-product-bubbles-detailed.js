(function () {
  'use strict';

  Polymer('ing-product-bubbles-detailed',{
      created: function() { 
      	this.products = []; 

        this.firstColor = "#E56500"; 
        this.secondColor = "#DD8822"; 
        this.color = "#EEAA22"; 
      },
      ready : function() {

        this.products = _.sortBy(this.products, function (product) { 
                              return parseFloat(product.balance); 
                            })
                         .reverse();

        this.totalAmount = _.reduce(this.products, function (total, product) { 
          return total + parseFloat(product.balance); 
        }, 0); 
      },

      getColor: function(productIndex) { 

        return (productIndex == 0) 
          ? this.firstColor
          : (productIndex == 1)
            ? this.secondColor
            : this.color;  
      }
  });

})();