var assert = chai.assert;
describe('<ing-product-bubbles>', function () {
    before(function(done) {
        var l = document.createElement('link');
        l.rel = 'import';
        l.href = 'base/Elements/ing-product-bubbles/ing-product-bubbles-detailed.html';
        document.head.appendChild(l);
        l.onload = function() {
          done();
        };
    });

    it('shoud get rendered', function () {
        // TODO: test it's rendered 
    });
});
