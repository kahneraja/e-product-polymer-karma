/**
 * Round a number by a specific precision or method
 * @param  {string} val
 */
PolymerExpressions.prototype.money = function (val) {
    return parseFloat(val).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
};