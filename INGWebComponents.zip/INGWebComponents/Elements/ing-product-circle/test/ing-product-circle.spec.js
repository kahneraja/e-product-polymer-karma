describe("ing-product-circle", function() {
  var $el;
  before(function(done) {

    var div = document.createElement('div');
    var tag = '<ing-product-circle amount="2352353.3688"></ing-product-circle>';
    div.innerHTML = tag;
    document.body.appendChild(div);
    $el = document.querySelector('ing-product-circle');

    done();

  });

  it('should be $2,352,353.36', function() {
    var amount = $el.shadowRoot.getElementById('amount').innerHTML;
    expect(amount).to.equal('$2,352,353.37');
  });

});
