(function () {
	'use strict';
	if (!Polymer.elements.filter(function(e){ return (e.name === 'ing-product-bubble') }).length)
		Polymer('ing-product-bubble',{
			ready : function  () {
			},
			colorChanged: function(oldValue, newValue) {
				this._setStyle('.product', 'backgroundColor', newValue);
			},
			radiusChanged: function(oldValue, newValue) {
				this._setStyle('.container', 'width', newValue);
				this._setStyle('.container', 'height', newValue);
				this._setStyle('.product', 'width', newValue);
				this._setStyle('.product', 'height', newValue);
			},
			amountSizeChanged: function  (oldValue, newValue) {
				this._setStyle('.amount', 'font-size', newValue);
			},
			productTextSizeChanged: function (oldValue, newValue) {
				this._setStyle('.product-name', 'font-size', newValue); 
			},
			_setStyle: function  (selector, style, newValue) {
				var myElements = this.shadowRoot.querySelectorAll(selector);
				for (var i = 0; i < myElements.length; i++) {
					myElements[i].style[style] = newValue;
				};
			}
		});

})();