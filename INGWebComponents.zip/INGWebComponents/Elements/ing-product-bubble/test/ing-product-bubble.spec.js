describe("ing-product-bubble", function() {
  var $el;
  before(function(done) {

    var div = document.createElement('div');
    var tag = '<ing-product-bubble name="day to day" number="1234" balance="1213" radius="25rem" color="#E56500" depth="1" top="2.3rem"></ing-product-bubble>';
    div.innerHTML = tag;
    document.body.appendChild(div);
    $el = document.querySelector('ing-product-bubble');

    done();

  });

  it('should be "day to day"', function() {
    expect(1).to.equal(1);
  });

});
