var assert = chai.assert;
var should = chai.should();
describe('<ing-product-bubbles>', function () {
    before(function(done) {
        var l = document.createElement('link');
        l.rel = 'import';
        l.href = 'base/Elements/ing-product-bubbles/ing-product-bubbles.html';
        document.head.appendChild(l);
        l.onload = function() {
          done();
        };
    });

    it('shoud get rendered', function () {
        var aElement = document.createElement('ing-product-bubbles');
        should.exist(aElement);
    });
});
