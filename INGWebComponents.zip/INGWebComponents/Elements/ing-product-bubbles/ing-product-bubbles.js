(function () {
	'use strict';
	Polymer('ing-product-bubbles',{
		created: function() {
			this.products = [];
			this.orderedProducts = [];
			this.colors = [
			'#E56500',
			'#EEAA22',
			'#DD8822',
			'#EEAA22'
			];
			this.radiuses = [
			'212px',
			'156px',
			'130px',
			'102px'
			]
		},
		ready: function  () {
			this.products = _.sortBy(this.products, function (product) { 
				return parseFloat(product.balance); 
			})
			.reverse();
			this.totalAmount = _.reduce(this.products, function (total, product) { 
				return total + parseFloat(product.balance); 
			}, 0); 
		},
		productsChanged:function  (oldValue, newValue) {

			//orderedProducts = sortProducts(newValue);
		}
	});
})();
